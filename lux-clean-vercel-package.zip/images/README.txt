=====================================
DOSSIER IMAGES - LUX CLEAN SERVICES
=====================================

📸 Mets toutes tes photos ici!

PHOTOS NÉCESSAIRES:
------------------

Avant/Après (avec logo):
1. sofa-avant-apres.jpg
2. tapis-avant-apres.jpg
3. plancher-avant-apres.jpg
4. chaise-avant-apres.jpg
5. sofa-gris-avant-apres.jpg
6. fauteuil-avant-apres.jpg

Salles de bain:
7. salle-bain-moderne.jpg
8. salle-bain-avant-apres.jpg

Cuisines:
9. cuisine-moderne.jpg

Commercial:
10. plancher-commercial.jpg

=====================================

🚀 APRÈS AVOIR AJOUTÉ TES IMAGES:

1. Ouvre index.html
2. Cherche "/images/placeholder.jpg"
3. Remplace par le bon nom de fichier

OU utilise les noms ci-dessus pour tes fichiers!

=====================================
